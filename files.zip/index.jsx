import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

export default function LoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please enter your email and password.');
      return;
    }
    setError('');
    setLoading(true);

    // TODO: replace with real auth call
    setTimeout(() => {
      setLoading(false);
      router.replace('/(tabs)/home');
    }, 800);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Cloud decorations */}
        <View style={styles.cloudTopLeft} />
        <View style={styles.cloudTopRight} />
        <View style={styles.cloudBottomLeft} />
        <View style={styles.cloudBottomRight} />

        <View style={styles.inner}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <View style={styles.logoBox}>
              <Ionicons name="moon" size={36} color="#fff" />
            </View>
            <Text style={styles.appName}>Sleep Diaries</Text>
            <Text style={styles.subtitle}>Login with your Sleep Diaries account</Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            {error ? (
              <Text style={styles.errorText}>{error}</Text>
            ) : null}

            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor="#A0B4CC"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputWrapper}>
              <TextInput
                style={[styles.input, { paddingRight: 48 }]}
                placeholder="Password"
                placeholderTextColor="#A0B4CC"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
              />
              <TouchableOpacity
                style={styles.eyeBtn}
                onPress={() => setShowPassword(!showPassword)}
              >
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color="#A0B4CC"
                />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
              onPress={handleLogin}
              activeOpacity={0.85}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.loginBtnText}>Login</Text>
              )}
            </TouchableOpacity>
          </View>

          {/* Sign up link */}
          <View style={styles.signupRow}>
            <Text style={styles.signupText}>Don't have an account? </Text>
            <TouchableOpacity onPress={() => console.log('Create account pressed')}>
              <Text style={styles.signupLink}>Create Account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#C8DFF5',
  },
  container: {
    flex: 1,
  },

  // Cloud decorations
  cloudTopLeft: {
    position: 'absolute',
    width: 160,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#DEEEFA',
    top: 20,
    left: -30,
    opacity: 0.8,
  },
  cloudTopRight: {
    position: 'absolute',
    width: 120,
    height: 55,
    borderRadius: 28,
    backgroundColor: '#DEEEFA',
    top: 50,
    right: -20,
    opacity: 0.7,
  },
  cloudBottomLeft: {
    position: 'absolute',
    width: 140,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#DEEEFA',
    bottom: 30,
    left: -20,
    opacity: 0.7,
  },
  cloudBottomRight: {
    position: 'absolute',
    width: 180,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#DEEEFA',
    bottom: 10,
    right: -30,
    opacity: 0.8,
  },

  inner: {
    flex: 1,
    paddingHorizontal: 32,
    justifyContent: 'center',
    gap: 32,
  },

  // Logo
  logoContainer: {
    alignItems: 'center',
    gap: 8,
  },
  logoBox: {
    width: 80,
    height: 80,
    borderRadius: 20,
    backgroundColor: '#4A7BB5',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
    transform: [{ rotate: '-8deg' }],
  },
  appName: {
    fontSize: 32,
    fontWeight: '800',
    color: '#E07A20',
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: 14,
    color: '#4A7BB5',
    textAlign: 'center',
  },

  // Form
  form: {
    gap: 14,
  },
  inputWrapper: {
    position: 'relative',
    justifyContent: 'center',
  },
  input: {
    backgroundColor: '#EEF5FF',
    borderWidth: 1.5,
    borderColor: '#B0CCEE',
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 14,
    fontSize: 16,
    color: '#1E3A5F',
  },
  eyeBtn: {
    position: 'absolute',
    right: 14,
    padding: 4,
  },
  errorText: {
    color: '#C0392B',
    fontSize: 13,
    textAlign: 'center',
    fontWeight: '500',
  },
  loginBtn: {
    backgroundColor: '#4A7BB5',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 4,
  },
  loginBtnDisabled: {
    backgroundColor: '#A0B4CC',
  },
  loginBtnText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },

  // Sign up
  signupRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signupText: {
    fontSize: 14,
    color: '#4A7BB5',
  },
  signupLink: {
    fontSize: 14,
    color: '#E07A20',
    fontWeight: '700',
    textDecorationLine: 'underline',
  },
});
